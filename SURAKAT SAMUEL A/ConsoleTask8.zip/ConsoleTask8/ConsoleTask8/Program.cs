﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;

namespace ConsoleTask8
{
    internal class Program
    {
        public static readonly string startMessage = "================================================ TODO APPLICATION  ===================================================";
        public static readonly string greetingMessage = "\"Welcome to Task Manager! ";
        public static readonly string userAuthenticationMessage = "1. Register  \n2. Login \n0. Exist ";
        public static readonly string userProfileMessage = "1. Add Task\n 2. View Task \n 3. Edit Task \n 4. Complete Task \n 5. Delete Task \n 0. Logout ";

        static void Main(string[] args)
        {
            List<User> users = new List<User>();


            while (true)
            {
                Console.WriteLine(startMessage);
                Console.WriteLine(greetingMessage);
                Console.WriteLine(userAuthenticationMessage);

                string option = Console.ReadLine();
                switch (option)
                {
                    case "1":
                        Register(users);
                        break;
                    case "2":
                        Login(users);
                        break;
                    case "0":
                        Console.ForegroundColor = ConsoleColor.DarkGreen;
                        Console.WriteLine("Goodbye!");
                        return;
                    default:
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalid input. Enter between {1,2,0}.");
                        break;
                }
                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Press any key to continue...");
                Console.ReadKey();
                Console.Clear();

            }

            static void Register(List<User> users)
            {
                Console.WriteLine("Please enter your Name:");
                string name = Console.ReadLine();
                Console.WriteLine("Please enter your Email:");
                string email = Console.ReadLine();
                while (!Regex.IsMatch(email, @"^[^\s@]+@[^\s@]+\.[^\s@]+$"))
                {
                    Console.WriteLine("Invalid email format. Please try again.");
                    Console.WriteLine("Please enter your email:");
                    email = Console.ReadLine();  
                }

                ///User Authentication
                Console.WriteLine("Please enter your password:");
                string password1 = Console.ReadLine();

                while (string.IsNullOrWhiteSpace(password1) || !Regex.IsMatch(password1, @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,}$"))
                {
                    Console.WriteLine("Password must be 8 characters, contain uppercase, lowercase, digit, and special character.");
                    password1 = Console.ReadLine();
                }

                Console.WriteLine("Please confirm your password:");
                string password2 = Console.ReadLine();

                while (string.IsNullOrWhiteSpace(password2) || password1 != password2)
                {
                    if (string.IsNullOrWhiteSpace(password2))
                    {
                        Console.WriteLine("Please enter a valid password.");
                    }
                    else
                    {
                        Console.WriteLine("Passwords do not match. Please try again.");
                    }
                    password2 = Console.ReadLine();
                }

                User user = new User(name, email, password2);
                users.Add(user);

                Console.WriteLine("Registration successful!");
            }


            static void Login(List<User> users)
            {
                Console.WriteLine("Please enter your email:");
                string email = Console.ReadLine();

                while (!Regex.IsMatch(email, @"^[^\s@]+@[^\s@]+\.[^\s@]+$"))
                {
                    Console.WriteLine("Invalid email format. Please try again.");
                    Console.WriteLine("Please enter your email:");
                    email = Console.ReadLine();
                }

                string password = "";
                while (string.IsNullOrWhiteSpace(password) || !Regex.IsMatch(password, @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,}$"))
                {
                    Console.WriteLine("Password must be 8 characters, contain uppercase, lowercase, digit, and special character.");
                    password = Console.ReadLine();
                }

                User user = users.FirstOrDefault(s => s.Email == email);
                if (user == null)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("User not Found");
                    Console.Clear();
                    return;
                }
                if (user.Password != password)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Invalid email or Password");
                    return;
                }
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Login successful!");
            }


            static void TaskMenu(List<User> users, User currentUser)
            {
                if (currentUser != null)
                {
                    List<Task> tasks = new List<Task>();

                    while (true)
                    {
                        Console.WriteLine(userProfileMessage);
                        

                        int userProfile = 0;

                        while (true)
                        {
                            Console.Write("Enter your choice: ");

                            if (int.TryParse(Console.ReadLine(), out userProfile) && userProfile >= 1 && userProfile <= 6)
                            {
                                break;
                            }

                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("Invalid response. Please enter a number between 1 and 6.");
                            Console.ResetColor();
                        }

                        switch (userProfile)
                        {
                            case 1:
                                AddTask(tasks);
                                break;
                            case 2:
                                viewTask(tasks);
                                break;
                            case 3:
                                EditTask(tasks);
                                break;
                            case 4:
                                DeleteTask(tasks);
                                break;
                            case 5:
                                CompleteTask(tasks);
                                break;
                            case 6:
                                Console.WriteLine("Logging out...");
                                currentUser = null;
                                return;
                            default:
                                Console.WriteLine("Invalid choice. Try again.");
                                break;
                        }
                    }
                }
                else
                {
                    Console.WriteLine(userProfileMessage);
                }
            }

            /// ADDTASK PANEL

            static void AddTask(List<Task> tasks)
            {

                Console.WriteLine("Title:");
                string titles = Console.ReadLine();

                Console.WriteLine("Description:");
                string description = Console.ReadLine();

                Console.WriteLine("Input Due date: \"DD-MM-YYYY\" ");
                string dueDate = Console.ReadLine();
                DateTime parsedDate;
                try
                {
                    parsedDate = DateTime.ParseExact(dueDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                }
                catch (FormatException)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Invalid date format. Please enter a date in the format \"DD-MM-YYYY\".");

                }

                Console.WriteLine("Periority Level:");
                string level = Console.ReadLine();

                PeriorityLevel periorityLevel;
                if (!Enum.TryParse(level, true, out periorityLevel))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Invalid");
                    return;
                }
                Task task = new Task(titles, description, dueDate, periorityLevel, CurrentUser.Id);
                tasks.Add(task);
                Console.WriteLine("Task Added successfully");

            }


            /// VIEW TASK PANEL

            static void viewTask(List<Task> tasks)
                    {

                        Console.WriteLine("All Tasks:");
                        List<Task> userTasks = tasks.FindAll(t => t.UserID == CurrentUser.Id);

                        if (userTasks.Count == 0)
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("No tasks found.");
                            return;
                        }
                        foreach (Task Task in tasks)
                        {
                            Console.WriteLine("|----------------------------------------------------------------------------------------------------|");
                            Console.WriteLine("|{0,-5} | {1,-20} | {2,-15} | {3,-15} | {4,-15} | {5,-14} |", "ID.", "Name", "Description", "Due Date", "Priority", "Status");
                            Console.WriteLine("|----------------------------------------------------------------------------------------------------|");
                            for (int i = 0; i < tasks.Count; i++)
                            {
                                Console.WriteLine("| {0,-4} | {1,-20} | {2,-15} | {3,-15} | {4,-15} | {5,-14} |", i + 1, tasks[i].Title, tasks[i].Description, tasks[i].Duedate, tasks[i].PeriorityLevel, tasks[i].isCompleted ? "Completed" : "Not Completed");
                            }
                            Console.WriteLine("|----------------------------------------------------------------------------------------------------|");
                        }


                    }


                    /// Deleting Task
                    static void DeleteTask(List<Task> tasks)
                    {

                        if (tasks.Count == 0)
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("No items.");
                            return;
                        }


                        Console.WriteLine("Select to Delete:");
                        string title = Console.ReadLine();

                        Task taskToDelete = tasks.FirstOrDefault(task => task.Title == title);

                        if (taskToDelete == null)
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("Task not found.");
                            return;
                        }

                        tasks.Remove(taskToDelete);
                        Console.WriteLine("Deleted successfully.");
                    }

                    static void EditTask(List<Task> tasks)
                    {
                        Console.WriteLine("Edit Task");
                        Console.WriteLine("Enter the Task Title");
                        string title = Console.ReadLine();
                        Task taskToEdit = tasks.FirstOrDefault(task => task.Title == title);
                        if (taskToEdit == null)
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("Task not found.");
                            return;

                        }
                        Console.WriteLine(" New Title:");
                        string newTitle = Console.ReadLine();

                        Console.WriteLine(" New Description:");
                        string newDescription = Console.ReadLine();

                        Console.WriteLine("Input New Due date:");
                        string newDueDate = Console.ReadLine();

                        Console.WriteLine("New Periority Level:");
                        string newLevel = Console.ReadLine();

                        PeriorityLevel periorityLevel;
                        if (!Enum.TryParse(newLevel, true, out periorityLevel))
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("Invalid");
                            return;
                        }
                        taskToEdit.Title = newTitle;
                        taskToEdit.Description = newDescription;
                        taskToEdit.Duedate = newDueDate;
                        taskToEdit.PeriorityLevel = periorityLevel;
                        Console.WriteLine("Task Updated Successfully");
                    }

            static void CompleteTask(List<Task> tasks)
            {
                Console.WriteLine("Complete Task");
                Console.WriteLine("Enter the Task Title:");
                string title = Console.ReadLine();

                Task taskToComplete = tasks.FirstOrDefault(task => task.Title == title);
                if (taskToComplete == null)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Task not found.");
                    return;
                }

                Console.Write("Is the task completed? (Yes/No): ");
                string input = Console.ReadLine().Trim().ToLower();

                if (input == "yes")
                {
                    taskToComplete.isCompleted = true;
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Task completed successfully.");
                }
                else if (input == "no")
                {
                    taskToComplete.isCompleted = false;
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("Task status updated to incomplete.");
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Invalid input. Task status not updated.");
                }
                Console.ResetColor();
            }


        }
    }   }
